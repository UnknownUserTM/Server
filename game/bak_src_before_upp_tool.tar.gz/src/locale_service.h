#ifndef __LOCALE_SERVCICE__
#define __LOCALE_SERVCICE__

#include "MultiLanguage.h"

#endif
